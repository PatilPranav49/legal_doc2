import re


class ClauseSplitter:

    @staticmethod
    def split(text: str):
        if not text or not text.strip():
            return []

        # Normalize spacing
        text = re.sub(r'\s+', ' ', text).strip()

        # Split on legal patterns
        clauses = re.split(
            r'(?:(?:\.\s)|(?:;\s)|(?:\n)|(?:\bprovided that\b)|(?:\bsubject to\b))',
            text,
            flags=re.IGNORECASE
        )

        # Clean clauses
        cleaned = []
        for c in clauses:
            c = c.strip()
            if len(c) > 20:  # ignore tiny noise
                cleaned.append(c)

        return cleaned